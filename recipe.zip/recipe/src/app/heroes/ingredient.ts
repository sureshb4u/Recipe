export interface Ingredient {
  "name": String,
}
