import {Ingredient} from './ingredient'
export interface Recipe {
  "name": String,
  "incredients": Ingredient[]
}
